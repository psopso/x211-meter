/* power_management.cpp */
#include <esp_sleep.h>
#include "config.h"

void goToSleep() {
    Serial.printf("Uspávám zařízení na %d sekund.\n", SLEEP_DURATION_S);
    Serial.println("===================================\n");
    Serial.flush(); // Ujistí se, že jsou všechny zprávy zapsány na sériový port
    
    // Nastavení probuzení časovačem
    esp_sleep_enable_timer_wakeup(SLEEP_DURATION_S * 1000000ULL);
    
    // Přechod do hlubokého spánku
    esp_deep_sleep_start();
}
