/* dlms_parser.h */
#pragma once
#include "config.h"

bool readAndParseFrame(MeterData& outData, unsigned long timeoutMs);
