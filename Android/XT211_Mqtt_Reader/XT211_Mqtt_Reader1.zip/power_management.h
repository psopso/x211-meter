/* power_management.h */
#pragma once

void goToSleep();
