#include "custom_comm.h"
#include "esp_err.h"
#include "esp_log.h"
#include "custom_ota.h"
#include "custom_time.h"
#include "custom_storage.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include <inttypes.h>
#include <stdbool.h>

// Tady vložíme závislosti na WiFi a MQTT jen pro tento soubor
#include "custom_config.h" // Pro SSID, hesla atd.
#include "custom_wifi.h"
#include "include/custom_comm.h"

#include <sys/time.h>

#ifdef USE_COMM_WIFI

#include "custom_mqtt.h"
#else
    #include "custom_lora.h"
	void convert_comm_data_to_lora_data(comm_msg_type_t type, comm_data_t *commdata, lora_universal_packet_t *packet, int *items_sent, size_t *out_size);
#endif

static const char *TAG = "COMM";
static const char *TAGPACKET = "LORA_PACKET";


bool wifi_is_initialized = false;

esp_err_t comm_init(void) {
#ifdef USE_COMM_WIFI
    ESP_LOGI(TAG, "Inicializace komunikace: WIFI + MQTT");
	wifi_is_initialized = true;
    return custom_wifi_init(WIFI_SSID, WIFI_PASSWORD, WIFI_IP, WIFI_GW, WIFI_NETMASK);
#else
    ESP_LOGI(TAG, "Inicializace komunikace: LORA");
    return custom_lora_init();
    //return ESP_OK;
#endif
}

bool comm_is_connected(void) {
#ifdef USE_COMM_WIFI
    return custom_wifi_is_connected();
#else
    // LoRa nevyžaduje "připojení" k AP, je vždy připravena vysílat
    return true; 
#endif
}

esp_err_t comm_send(comm_msg_type_t type, comm_data_t *data) {
	ESP_LOGI(TAG, "Comm Send: %d, Status: %s", type, data->state);
    if (data == NULL) return ESP_ERR_INVALID_ARG;

#ifdef USE_COMM_WIFI
    if (!custom_wifi_is_connected()) return ESP_FAIL;

    switch (type) {
        case MSG_TYPE_METER_DATA:
			ESP_LOGI(TAG, "Odeslani DATA do mqtt");
            // Tady pošleme JEN data z elektroměru
            // Předpokládám, že vaše funkce custom_mqtt_send_data 
            // interně bere data z 'parsed_data'. 
            // Můžete ji upravit, aby brala 'data->meter_data'.
//            return custom_mqtt_send_data(&(data->meter_data)); 
            custom_mqtt_send_data();
			return ESP_OK;

        case MSG_TYPE_STATUS:
			ESP_LOGI(TAG, "Odeslani STATUS do mqtt");
            // Tady pošleme diagnostický balík proměnných
            /*return*/ custom_mqtt_send_status(
                CMD_STATUS, 
                data->state, 
                data->reason, 
                data->boot_count, 
                data->wakeup_cycle_count,
				data->first_boot_time,
//				data->wait_time,
//                data->wait_time_min,
//				data->wait_time_max,
				data->rssi,
				data->adaptive_offset,
				data->start_time_str,
				data->next_wakeup_str,
				data->ntp_drift,
				(double)data->battery_voltage,
				(double)data->battery_soc,
				data->serialno
                // ... a tak dále (všechny ty diagnostické proměnné)
//custom_mqtt_send_status(CMD_STATUS, "OK", "After wakeup", bootCount, 
//   wakeUpCycleCounter, firstBootTime, waitTime, waitTimeMin, waitTimeMax, 
//   check_signal_strength(), adaptive_offset, s_short, next_wakeup_str_pers, drift);
//	
//    state, reason,boot_count,wakeup_cycle_count,first_boot_time,wait_time,
//    wait_time_min,wait_time_max,RSSI,adaptive_offset,startTime,next_wakeup_str,drift;
				
            );
			return ESP_OK;

        case MSG_TYPE_BATTERY:
			ESP_LOGI(TAG, "Odeslani BATTERY do mqtt");
            // Tady pošleme jen info o baterce
            /*return*/// custom_mqtt_send_battery(data->battery_voltage, data->battery_soc);
            custom_mqtt_send_status(CMD_BATTERY, 
              data->battery_voltage, 
              data->battery_soc
			);
			return ESP_OK;
        default:
            return ESP_ERR_NOT_SUPPORTED;
    }
#else
    // LoRa sekce uvnitř comm_send
    lora_universal_packet_t lora_packet = {0};
    lora_packet.network_id = MY_SECRET_NETWORK_ID;
    lora_packet.sender_id = SENDER_ID_METER;

    int items_sent = 0;
    size_t payload_size = 0;

    // Tahle jedna funkce obslouží DATA, STATUS i BATTERY!
    convert_comm_data_to_lora_data(type, data, &lora_packet, &items_sent, &payload_size);

    if (payload_size > 0) {


//Následující řádky bude možno po odladění smazat
//        ESP_LOGI(TAG, "Odesilam LoRa paket. Typ: %d, Polozek: %d, Velikost: %zu B", 
//                 type, items_sent, payload_size);
//                 
//        esp_err_t espstatus = custom_lora_send_packet((uint8_t *)&lora_packet, payload_size); 
//        // ... timeout, cekani na ACK ...
//        if (espstatus == ESP_OK)
//        	espstatus = custom_lora_receive_packet();
//        return espstatus;

		ESP_LOGI(TAG, "Odesilam LoRa paket. Typ: %d, Polozek: %d, Velikost: %zu B", 
           type, items_sent, payload_size);

		esp_err_t espstatus = ESP_FAIL;
		
		for (int attempt = 1; attempt <= LORA_MAX_RETRIES; attempt++) {
		    ESP_LOGI(TAG, "--- Pokus o odeslani: %d/%d ---", attempt, LORA_MAX_RETRIES);
		    //Vypočíst CRC
		    size_t data_len = payload_size;
		    // 2. Vypočítáme CRC z těla paketu
    		const uint8_t *bytes = (uint8_t*)&lora_packet;
    		// 3. Vypočítáme CRC z těla paketu
    		lora_packet.crc = esp_rom_crc16_le(0, bytes, data_len);
		    // 1. Odeslání paketu
		    espstatus = custom_lora_send_packet((uint8_t *)&lora_packet, payload_size+2); 
		    
		    if (espstatus == ESP_OK) {
		        // 2. Vysílání proběhlo, jdeme poslouchat odpověď (ACK)
		        espstatus = custom_lora_receive_packet();
		        
		        if (espstatus == ESP_OK) {
		            ESP_LOGI(TAG, "ACK uspesne prijato! Attempt: %d", attempt);
		            break; // ÚSPĚCH! Vyskakujeme z for-smyčky a jdeme dál
		            
		        } else if (espstatus == ESP_ERR_TIMEOUT) {
		            ESP_LOGW(TAG, "Vyprsel timeout pro prijem ACK (pokus %d).", attempt);
		        } else {
		            ESP_LOGE(TAG, "Jina chyba pri prijmu: %s", esp_err_to_name(espstatus));
		        }
		    } else {
		        ESP_LOGE(TAG, "Chyba pri samotnem vysilani: %s", esp_err_to_name(espstatus));
		        // Pokud selže už samotná komunikace s čipem (SPI), nemá smysl hned opakovat
		    }
		
		    // 3. Pokud to nebyl poslední pokus a nedopadlo to dobře, chvíli počkáme
		    if (attempt < LORA_MAX_RETRIES) {
		        ESP_LOGI(TAG, "Cekam %d ms pred dalsim pokusem...", LORA_RETRY_DELAY_MS);
		        vTaskDelay(pdMS_TO_TICKS(LORA_RETRY_DELAY_MS));
		    }
		}

		// Vrátí ESP_OK (pokud se to v nějakém pokusu povedlo), 
		// nebo poslední chybový kód (pokud selhaly všechny pokusy)
		if ((espstatus == ESP_OK) && (type == 0)) {
		    //Tady bychom měli smazat něco z počátku fronty, pouze v případě, že jde o datový paket
		    //Možná budeme mazat pouze, pokud fronta bude delší, než 8 (=>)  LORA_MAX_ITEMS_PER_PACKET=8
		    //a smažeme právě 8 záznamů
		    if (storage_get_queue_count() >= LORA_MAX_ITEMS_PER_PACKET) {
		      ESP_LOGI(TAG,"Mazu %d zaznamů z fronty.", LORA_MAX_ITEMS_PER_PACKET);
                      storage_remove_entries(LORA_MAX_ITEMS_PER_PACKET);
		    }
		}
		return espstatus;
    }
    
    return ESP_FAIL;
#endif
}

int8_t check_signal_strength() {
#ifdef USE_COMM_WIFI
	return check_wifi_signal_strength();
#else
	return 0;
#endif

}

esp_err_t comm_ota_check_and_do_update(const char *url, bool forceota) {
#ifdef USE_COMM_WIFI
	return simple_ota_check_and_do_update(url);
#else
	if (forceota) {
		if (!wifi_is_initialized) {
			custom_wifi_init(WIFI_SSID, WIFI_PASSWORD, WIFI_IP, WIFI_GW, WIFI_NETMASK);
			wifi_is_initialized = true;
		}
		return simple_ota_check_and_do_update(url);
	} else {
		return ESP_ERR_NOT_SUPPORTED; //ESP_OK;
	}
#endif
}

void comm_time_sync_from_ntp() {
#ifdef USE_COMM_WIFI
    ESP_LOGI(TAG, "Debug: time_sync_from_ntp");
	time_sync_from_ntp();
#else
    ESP_LOGI(TAG, "Debug: ---");
#endif
}

 //Queue size 100
//[LORA_MAX_ITEMS_PER_PACKET]; // 4 * 17 = 68 bytes  8 * 17 = 136  100/8 = 12 paketů = celá fronta
//když odešlu 3 pakety, tak to mám celou frontu na 4x
//100 byte 300ms, 8 paketů = 140 bytů, tedy asi 400ms, mohu poslat 16 paketů do 1 sekundy. Tedy celou frontu pošlu na 6x
#ifndef USE_COMM_WIFI
// Pomocná funkce pro převod stringu na číslo (upravte podle vašich reálných stavů)
uint8_t map_state_to_code(const char* state) {
    if (state == NULL) return 0;
    if (strcmp(state, "OK") == 0) return 0;
    if (strcmp(state, "SLEEP") == 0) return 1;
    if (strcmp(state, "RS485TIMEOUT") == 0) return 2;
    if (strcmp(state, "FAILED") == 0) return 99;
    return 255; // Neznámý
}

uint8_t map_reason_to_code(const char* reason) {
    if (reason == NULL) return 0;
    if (strcmp(reason, "OK") == 0) return 0;
    if (strcmp(reason, "SLEEP") == 0) return 1;
    if (strcmp(reason, "RS485TIMEOUT") == 0) return 2;
    if (strcmp(reason, "FAILED") == 0) return 99;
    return 255; // Neznámý
}

//void convert_comm_data_to_lora_data(comm_msg_type_t type, comm_data_t *commdata, lora_data_payload_t *payload, int *items_sent) {
void convert_comm_data_to_lora_data(comm_msg_type_t type, comm_data_t *commdata, lora_universal_packet_t *packet, int *items_sent, size_t *out_size) {	
	packet->packet_type = (uint8_t)type; // Zajištění, že paket má správný typ
	
    switch (type) {
        case MSG_TYPE_METER_DATA:
		  ESP_LOGI(TAG, "Odeslani DATA do mqtt");
		  *items_sent = 0;
		  ESP_LOGI(TAG, "Priprava dat na odeslani: %d %d", (uint8_t)storage_get_queue_count(), (uint8_t)LORA_MAX_ITEMS_PER_PACKET);
	      for (int i = 0; i < storage_get_queue_count() && i < LORA_MAX_ITEMS_PER_PACKET; i++) {
	        data_queue_entry_t entry;
	        if (storage_get_queue_entry(i, &entry)) {
	            data_queue_entry_t *src = &entry;
	            lora_queue_item_t *dst = &packet->payload.items[i];
	            
	            dst->timestamp = (uint32_t)src->timestamp;
	            // Převod kWh (double) na Wh (uint32)
	            dst->obis_1_8_0_Wh = (uint32_t)(src->data.obis_1_8_0 * 1000.0);
	            dst->obis_1_8_1_Wh = (uint32_t)(src->data.obis_1_8_1 * 1000.0);
	            dst->obis_1_8_2_Wh = (uint32_t)(src->data.obis_1_8_2 * 1000.0);
	            dst->first_after_restart = src->first_after_restart ? 1 : 0;
	            if (src->waittime > 255)
	              dst->waittime = 255;
	            else
	            	dst->waittime = src->waittime;	
	            *items_sent += 1;
	      	}
      	  }
      	  packet->item_count = (uint8_t)*items_sent;
      	  // Spočítáme přesnou velikost paketu (Hlavička + počet záznamů)
          *out_size = offsetof(lora_universal_packet_t, payload) + (*items_sent * sizeof(lora_queue_item_t));
      	  return;
      	case MSG_TYPE_STATUS:
  		    ESP_LOGI(TAG, "Priprava STATUS pro LoRa");
            if (commdata == NULL) return; // Ochrana
            
            *items_sent = 1;
            packet->item_count = 1;
            
            lora_status_item_t *dst = &packet->payload.status;
            
            // Konverze textů na čísla
            dst->state_code = map_state_to_code(commdata->state);
            ESP_LOGI(TAG, "Converted statecode: %d", dst->state_code);
            //commdata->reason;
            dst->reason_code = 0; // Tady si můžete udělat podobnou mapovací funkci
            
            // Přímé přiřazení a oříznutí velikostí
            dst->boot_count = (uint32_t)commdata->boot_count;
            dst->wakeup_cycle_count = (uint32_t)commdata->wakeup_cycle_count;
            dst->first_boot_time = (uint32_t)commdata->first_boot_time;
            dst->esp32_time = (uint32_t)time(NULL);   //commdata->esp32_time;

            dst->adaptive_offset = commdata->adaptive_offset;
            
            // Konverze zlomků na celá čísla (drift z double na int16 v ms)
            dst->ntp_drift_ms = (int16_t)(commdata->ntp_drift * 1000.0);
            
            dst->rssi = (int8_t)commdata->rssi;
            dst->batt_voltage_mv = (uint16_t)(commdata->battery_voltage * 1000.0);
            dst->batt_soc = (uint8_t)commdata->battery_soc;
            
            ESP_LOGI(TAG, "Odeslani STATUS do mqtt obis_96_1_1: %s", commdata->meter_data.obis_96_1_1);
            uint64_t sn64 = strtoull(commdata->serialno, NULL, 10);
            // Do sn1 uložíme spodních 32 bitů (maskování hodnotou 0xFFFFFFFF)
		    dst->serialno.sn1 = (uint32_t)(sn64 & 0xFFFFFFFF);
    		// Do sn2 posuneme horní bity o 32 míst doprava
    		dst->serialno.sn2 = (uint8_t)(sn64 >> 32);

            // Řetězce start_time_str a next_wakeup_str NEPOSÍLÁME!
            // ESPHome si je na straně serv eru případně vypočítá z času a wait_time.

            *out_size = offsetof(lora_universal_packet_t, payload) + sizeof(lora_status_item_t);
      	    return;
      	case MSG_TYPE_BATTERY:
      	  return;
      	case MSG_TYPE_REPLYSTATUS:
      	  return;
      }
}

size_t get_packet_payload_len(const lora_universal_packet_t *pkt) {
    size_t header_len = sizeof(pkt->network_id) + 
                       sizeof(pkt->sender_id) + 
                       sizeof(pkt->packet_type) + 
                       sizeof(pkt->item_count); // 5 bajtů

    switch (pkt->packet_type) {
        case MSG_TYPE_METER_DATA:
            return header_len + (pkt->item_count * sizeof(lora_queue_item_t));
        case MSG_TYPE_STATUS:
            return header_len + sizeof(lora_status_item_t);
        case MSG_TYPE_REPLYSTATUS:
            return header_len + sizeof(lora_reply_status);
        default:
            return header_len;
    }
}

bool verify_received_packet(const uint8_t *rx_buf, size_t rx_len) {
    size_t min_header_len = 5; // 2B net_id + 1B sender + 1B type + 1B count

    // 1. Minimální délka: Hlavička + 2B pro CRC
    if (rx_len < (min_header_len + sizeof(uint16_t))) {
        ESP_LOGE(TAG, "Prijaty paket je prilis kratky: %zu B", rx_len);
        return false;
    }

    // Nahlédneme do hlavičky (přetypujeme začátek bufferu)
    const lora_universal_packet_t *pkt = (const lora_universal_packet_t *)rx_buf;

    // 2. Vypočítáme, kolik bajtů dat očekáváme podle typu zprávy
    size_t expected_data_len = get_packet_payload_len(pkt);

    if (expected_data_len == 0) {
        ESP_LOGE(TAG, "Neznamy typ zpravy: %u", pkt->packet_type);
        return false;
    }

    // Celková očekávaná délka paketu z rádia (data + 2B CRC na konci)
    size_t expected_total_len = expected_data_len + sizeof(uint16_t);

    if (rx_len != expected_total_len) {
        ESP_LOGE(TAG, "Nesouhlasí delka paketu! Prijato: %zu B, Ocekavano: %zu B", rx_len, expected_total_len);
        return false;
    }

    // 3. Bezpečné přečtení CRC z konce přijatého bufferu (bajt po bajtu, Little-Endian)
    uint16_t rx_crc = (uint16_t)rx_buf[expected_data_len] | 
                     ((uint16_t)rx_buf[expected_data_len + 1] << 8);

    // 4. Spočítáme CRC z užitečných dat
    uint16_t calc_crc = esp_rom_crc16_le(0, rx_buf, expected_data_len);

    // 5. Porovnání
    if (rx_crc != calc_crc) {
        ESP_LOGE(TAG, "CRC CHYBA! Prijato: 0x%04X, Vypocteno: 0x%04X", rx_crc, calc_crc);
        return false;
    }

    ESP_LOGI(TAG, "Paket uspesne overen (CRC: 0x%04X, Delka: %zu B)", rx_crc, expected_data_len);

    // 6. Zde můžete bezpečně zavolat dříve připravený log_lora_packet(pkt)
    // log_lora_packet(pkt);

    return true;
}

//static const char *TAG = "TIME_SET";

void log_lora_packet(const lora_universal_packet_t *pkt, uint16_t crc) {
    if (pkt == NULL) {
        ESP_LOGE(TAGPACKET, "Ukazatel na paket je NULL!");
        return;
    }

    // 1. Společná hlavička paketu
    ESP_LOGI(TAGPACKET, "--- [ LoRa Universal Packet ] ---");
    ESP_LOGI(TAGPACKET, "  Network ID  : 0x%04X", pkt->network_id);
    ESP_LOGI(TAGPACKET, "  Sender ID   : %u", pkt->sender_id);
    ESP_LOGI(TAGPACKET, "  Packet Type : %u", pkt->packet_type);
    ESP_LOGI(TAGPACKET, "  Item Count  : %u", pkt->item_count);
    ESP_LOGI(TAGPACKET, "  CRC         : 0x%04X", crc);

    // 2. Rozbalení konkrétního obsahu unionu podle typu zprávy
    switch (pkt->packet_type) {
        case MSG_TYPE_METER_DATA:
            ESP_LOGI(TAGPACKET, "  Payload     : METER_DATA (%u polozek v poli)", pkt->item_count);
            // Zde stačí výpis počtu položek dle vašeho zadání
            break;

        case MSG_TYPE_STATUS: {
            const lora_status_item_t *st = &pkt->payload.status;
            ESP_LOGI(TAGPACKET, "  Payload     : STATUS");
            ESP_LOGI(TAGPACKET, "    State Code       : %u", st->state_code);
            ESP_LOGI(TAGPACKET, "    Reason Code      : %u", st->reason_code);
            ESP_LOGI(TAGPACKET, "    Boot Count       : %" PRIu32, st->boot_count);
            ESP_LOGI(TAGPACKET, "    Wakeup Cycles    : %" PRIu32, st->wakeup_cycle_count);
            ESP_LOGI(TAGPACKET, "    First Boot Time  : %" PRIu32, st->first_boot_time);
            ESP_LOGI(TAGPACKET, "    ESP32 Time       : %" PRIu32, st->esp32_time);
            ESP_LOGI(TAGPACKET, "    Adaptive Offset  : %" PRIi32, st->adaptive_offset);
            ESP_LOGI(TAGPACKET, "    NTP Drift (ms)   : %d", (int)st->ntp_drift_ms);
            ESP_LOGI(TAGPACKET, "    RSSI             : %d dBm", (int)st->rssi);
            ESP_LOGI(TAGPACKET, "    Battery Voltage  : %u mV", (unsigned int)st->batt_voltage_mv);
            ESP_LOGI(TAGPACKET, "    Battery SoC      : %u %%", st->batt_soc);
            ESP_LOGI(TAGPACKET, "    Serial No        : %08" PRIX32 "%02X", st->serialno.sn1, st->serialno.sn2);
            break;
        }

		case MSG_TYPE_REPLYSTATUS: {
            const lora_reply_status *rsp = &pkt->payload.lorareplystatus;
            ESP_LOGI(TAGPACKET, "  Payload     : REPLYSTATUS");
            ESP_LOGI(TAGPACKET, "    Reply Status     : %u", rsp->replystatus);
            ESP_LOGI(TAGPACKET, "    NTP Time       : %" PRIu32, rsp->ntp_time);
            break;
        }
        
        case MSG_TYPE_BATTERY:
            // Pokud máte pro BATTERY samostatné zpracování nebo používáte reply status:
            ESP_LOGI(TAGPACKET, "  Payload     : BATTERY / REPLY_STATUS");
            ESP_LOGI(TAGPACKET, "    Reply Status     : %u", pkt->payload.lorareplystatus.replystatus);
            ESP_LOGI(TAGPACKET, "    NTP Time       : %" PRIu32, pkt->payload.lorareplystatus.ntp_time);
            break;

        default:
            ESP_LOGW(TAGPACKET, "  Payload     : NEZNAMY TYP ZPRAVY (%u)", pkt->packet_type);
            break;
    }
    ESP_LOGI(TAGPACKET, "---------------------------------");
}
#endif

/*
Pro dosazení 10místného čísla 5542684578 do vaší 5bajtové struktury musíte hodnotu rozdělit pomocí bitových posunů. Číslo 5542684578 (v šestnáctkové soustavě 0x14A5EA7A2) se totiž nevejde do klasického 32bitového registru uint32_t, který má maximum 4294967295.
Protože je cílem minimální délka pro přenos přes LoRa, je toto čistě binární rozdělení (využití všech 5 bajtů jako jednoho velkého 40bitového čísla) tím nejefektivnějším možným řešením.
## Příklad v C / C++
Pro uložení takto velkého čísla v kódu musíte nejprve použít 64bitovou proměnnou typu uint64_t a následně ji "rozřezat" na spodní 4 bajty a horní 1 bajt.

#include <iostream>#include <cstdint>
#pragma pack(push, 1)typedef struct {
    uint32_t sn1; // Spodní 4 bajty (0 až 31. bit)
    uint8_t sn2;  // Horní 1 bajt (32. až 39. bit)
} serialno_t;#pragma pack(pop)
int main() {
    // 10místné sériové číslo (vyžaduje uint64_t)
    uint64_t obis_96_1_1 = 5542684578ULL; 

    serialno_t serialno;

    // Do sn1 uložíme spodních 32 bitů (maskování hodnotou 0xFFFFFFFF)
    serialno.sn1 = (uint32_t)(obis_96_1_1 & 0xFFFFFFFF);

    // Do sn2 posuneme horní bity o 32 míst doprava
    serialno.sn2 = (uint8_t)(obis_96_1_1 >> 32);

    // --- Ověření výsledku ---
    std::cout << "Zapsáno do struktury:" << std::endl;
    std::cout << "serialno.sn1: " << serialno.sn1 << " (0x" << std::hex << serialno.sn1 << ")" << std::endl;
    std::cout << "serialno.sn2: " << (int)serialno.sn2 << " (0x" << std::hex << (int)serialno.sn2 << ")" << std::endl;

    // Zpětná rekonstrukce čísla (např. na straně serveru / brány)
    uint64_t rekonstrukce = ((uint64_t)serialno.sn2 << 32) | serialno.sn1;
    std::cout << std::dec << "Původní číslo po rekonstrukci: " << rekonstrukce << std::endl;

    return 0;
}


## Jak to funguje v paměti?
Číslo 5542684578 je binárně:
00000001 01001010 01011110 10100111 10100010

* serialno.sn1 dostane hodnotu 1247717282 (0x4A5EA7A2), což jsou spodní 4 bajty.
* serialno.sn2 dostane hodnotu 1 (0x01), což je zbývající horní 1 bajt.

Při odesílání struktury přes LoRa (např. pomocí funkce pro odeslání pole bajtů) odešlete přesně 5 bajtů bez jakékoliv textové režie, což je pro LoRaWAN protokoly ideální payload.
Pokud budete data na straně serveru (např. v ChirpStacku nebo Node-RED) dekódovat, dejte mi vědět, v jakém jazyce běží váš parser (např. JavaScript / Payload Formatter). Mohu vám pro něj připravit dekódovací funkci.

obis = 5542684578# Hexadecimal representationhex_val = hex(obis)
print(f"Hex: {hex_val}")# Total bytes neededimport mathbytes_needed = math.ceil(obis.bit_length() / 8)
print(f"Bytes: {bytes_needed}")
# Split into 4 bytes (lower) and 1 byte (upper)# obis = sn2 * 2^32 + sn1sn2 = obis >> 32sn1 = obis & 0xFFFFFFFF
print(f"sn2: {sn2}, sn1: {sn1}")
print(f"Verify: {(sn2 << 32) + sn1}")
*/
