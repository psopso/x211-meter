#pragma once
#include "esp_err.h"

esp_err_t time_sync_from_ntp(void);

void set_system_time(int64_t epoch_seconds);
